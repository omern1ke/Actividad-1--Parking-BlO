# Parking BLO - HTML semántico y CSS básico

Proyecto académico de una página de parqueaderos para Quibdó.

La página utiliza HTML5 semántico con header, nav, main, section, article, aside y footer, acompañado de un archivo CSS externo con estilos básicos.
